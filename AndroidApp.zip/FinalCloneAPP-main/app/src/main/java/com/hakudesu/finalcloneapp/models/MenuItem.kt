package com.hakudesu.finalcloneapp.models


data class MenuItemData(
    val name: String,
    val price: String,
    val imageRes: Int
)